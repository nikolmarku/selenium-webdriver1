package junit.test;

public class Addition {
    public int addNumbers(int a, int b){
        int sum = a + b;
        return sum; 
    }
}