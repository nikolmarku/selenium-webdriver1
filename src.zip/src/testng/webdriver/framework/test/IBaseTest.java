package testng.webdriver.framework.test;
/**
 * Use this the enforce must implement methods 
 * @author nikolmarku
 *
 */
public interface IBaseTest {

}
